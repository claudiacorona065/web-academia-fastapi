from sqlalchemy import Column, Integer, String, Boolean, Text, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime
import enum


# Tipos de usuario
class TipoUsuario(enum.Enum):
    profesor = "profesor"
    estudiante = "super"
    admin = "admin"

# Tabla de roles: super, admin, user
class Rol(Base):
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(50), unique=True, nullable=False)



class Usuario(Base):
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    apellidos = Column(String(100))
    email = Column(String(100), unique=True, nullable=False)
    password = Column(String(255), nullable=False)
    tipo = Column(String(50), default="user")
    fecha_creacion = Column(DateTime, default=datetime.utcnow)
    fecha_modificacion = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    habilitado = Column(Boolean, default=True)
    id_rol = Column(Integer, ForeignKey("roles.id"))

    rol = relationship("Rol")
    solicitudes = relationship("SolicitudCurso", back_populates="solicitante")
    cursos_impartidos = relationship("Curso", back_populates="profesor")


    

# Tabla de cursos
class Curso(Base):
    __tablename__ = "cursos"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(Text)
    duracion = Column(Integer)
    disponible = Column(Boolean, default=True)
    plazas_disponibles = Column(Integer, nullable=False, default=20)

    id_profesor = Column(Integer, ForeignKey("usuarios.id"))
    profesor = relationship("Usuario", back_populates="cursos_impartidos")


# Tabla intermedia: inscripciones a cursos
class Inscripcion(Base):
    __tablename__ = "usuarios_cursos"

    id = Column(Integer, primary_key=True, index=True)
    id_usuario = Column(Integer, ForeignKey("usuarios.id"))
    id_curso = Column(Integer, ForeignKey("cursos.id"))
    fecha_inscripcion = Column(DateTime, default=datetime.utcnow)


class SolicitudCurso(Base):
    __tablename__ = "solicitudes"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(String(255), nullable=False)
    duracion = Column(Integer, nullable=False)
    id_usuario = Column(Integer, ForeignKey("usuarios.id"))

    solicitante = relationship("Usuario", back_populates="solicitudes")