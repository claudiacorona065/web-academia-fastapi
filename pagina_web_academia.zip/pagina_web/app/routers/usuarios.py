from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Usuario, Curso, Inscripcion
from app.schemas import TokenData, LoginRequest, UsuarioCreate
from jose import jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from app.dependencies import verificar_rol_super, verificar_rol_admin, get_current_user
from sqlalchemy.orm import relationship
from app.models import Rol
from app.schemas import UsuarioUpdate
from app.schemas import ProfesorOut
from typing import List
from app.dependencies import verificar_rol_super
from app.schemas import UsuarioTipoUpdate
router = APIRouter(
    prefix="/auth",
    tags=["auth"]
)


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

SECRET_KEY = "claveultrasecreta"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# ---------------------- FUNCIONES AUXILIARES ----------------------

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str):
    return pwd_context.hash(password)

# ---------------------- LOGIN ----------------------
@router.post("/login")
def login(request: LoginRequest, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.email == request.email).first()
    if not usuario:
        raise HTTPException(status_code=401, detail="Email no registrado")
    if not usuario.habilitado:
        raise HTTPException(status_code=403, detail="Usuario no habilitado")
    if not verify_password(request.contrasena, usuario.password):
        raise HTTPException(status_code=401, detail="Contraseña incorrecta")

    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(usuario.id),
        "rol": usuario.id_rol,
        "exp": expire
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

    return {
        "access_token": token,
        "token_type": "bearer"
    }
# ---------------------- REGISTRO ----------------------
@router.post("/usuarios")
def registrar_usuario(
    usuario: UsuarioCreate,
    db: Session = Depends(get_db),
):
    if db.query(Usuario).filter(Usuario.email == usuario.email).first():
        raise HTTPException(status_code=400, detail="Ese email ya está registrado")

    # ✅ Solo permitir creación libre de usuarios normales (rol 3)
    if usuario.id_rol != 3:
        raise HTTPException(status_code=403, detail="Solo se permite el registro de usuarios normales")

    nuevo_usuario = Usuario(
        nombre=usuario.nombre,
        apellidos=usuario.apellidos,
        email=usuario.email,
        password=get_password_hash(usuario.contrasena),
        tipo=usuario.tipo,  # debe ser: 'estudiante', 'profesor' o 'otro'
        id_rol=usuario.id_rol,
        habilitado=True
    )

    db.add(nuevo_usuario)
    db.commit()
    db.refresh(nuevo_usuario)
    return {"mensaje": f"Usuario {nuevo_usuario.nombre} creado correctamente", "usuario_id": nuevo_usuario.id}

# ---------------------- LISTAR USUARIOS ----------------------
@router.get("/usuarios", dependencies=[Depends(verificar_rol_admin)])
def listar_usuarios(db: Session = Depends(get_db)):
    return db.query(Usuario).all()

# ---------------------- DESHABILITAR USUARIO ----------------------
@router.put("/usuarios/{usuario_id}/deshabilitar", dependencies=[Depends(verificar_rol_super)])
def deshabilitar_usuario(usuario_id: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    usuario.habilitado = False
    db.commit()
    return {"mensaje": f"Usuario {usuario.email} ha sido deshabilitado"}

# ---------------------- HABILITAR USUARIO ----------------------
@router.put("/usuarios/{usuario_id}/habilitar", dependencies=[Depends(verificar_rol_super)])
def habilitar_usuario(usuario_id: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    usuario.habilitado = True
    db.commit()
    return {"mensaje": f"Usuario {usuario.email} ha sido habilitado"}

# ---------------------- HACER ADMIN ----------------------
@router.put("/usuarios/{usuario_id}/hacer-admin", dependencies=[Depends(verificar_rol_super)])
def hacer_admin(usuario_id: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    usuario.id_rol = 2
    usuario.tipo = "admin"
    db.commit()
    return {"mensaje": f"Usuario {usuario.email} ahora es administrador"}

# ---------------------- MIS CURSOS ----------------------
@router.get("/mis-cursos", tags=["usuarios"])
def obtener_mis_cursos(
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    inscripciones = db.query(Inscripcion).filter_by(id_usuario=usuario.id).all()
    ids_cursos = [i.id_curso for i in inscripciones]
    cursos = db.query(Curso).filter(Curso.id.in_(ids_cursos)).all()
    return cursos

@router.get("/roles")
def obtener_roles(db: Session = Depends(get_db)):
    return db.query(Rol).all()  # Obtiene todos los roles de la base de datos

# ---------------------- QUITAR ADMIN ----------------------
@router.put("/usuarios/{usuario_id}/quitar-admin", dependencies=[Depends(verificar_rol_super)])
def quitar_admin(usuario_id: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    # Restaurar el rol a "user"
    usuario.id_rol = 3  # Vuelve a rol de "usuario"
    usuario.tipo = "user"  # Tipo de usuario
    db.commit()
    return {"mensaje": f"Usuario {usuario.email} ha sido removido de administrador y ahora es un usuario regular"}


solicitudes = relationship("SolicitudCurso", back_populates="solicitante")

@router.get("/lista-profesores", response_model=List[ProfesorOut])
def obtener_profesores(db: Session = Depends(get_db)):
    return db.query(Usuario).filter(Usuario.tipo == "profesor").all()




# ---------------------- EDITAR PERFIL ----------------------
@router.put("/usuarios/editar-perfil")
def editar_perfil(
    datos: UsuarioUpdate,
    db: Session = Depends(get_db),
    usuario_actual: Usuario = Depends(get_current_user)
):
    usuario = db.query(Usuario).filter(Usuario.id == usuario_actual.id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    usuario.nombre = datos.nombre
    usuario.apellidos = datos.apellidos
    usuario.email = datos.email

    db.commit()
    db.refresh(usuario)
    return {"mensaje": "Perfil actualizado correctamente"}

@router.put("/usuarios/{usuario_id}/cambiar-rol")
def cambiar_tipo_usuario(
    usuario_id: int,
    datos: UsuarioTipoUpdate,
    db: Session = Depends(get_db),
    superadmin: Usuario = Depends(verificar_rol_super)
):
    usuario = db.query(Usuario).filter(Usuario.id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    usuario.tipo = datos.tipo
    db.commit()
    db.refresh(usuario)
    return {"mensaje": f"Tipo actualizado a {datos.tipo}"}