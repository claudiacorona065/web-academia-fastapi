from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import SolicitudCurso, Usuario
from app.dependencies import get_current_user
from pydantic import BaseModel
from app.dependencies import verificar_rol_admin

router = APIRouter(
    prefix="/solicitudes",
    tags=["solicitudes"]
)


class SolicitudCreate(BaseModel):
    nombre: str
    descripcion: str
    duracion: int

@router.get("/", dependencies=[Depends(verificar_rol_admin)])
def obtener_solicitudes(db: Session = Depends(get_db)):
    return db.query(SolicitudCurso).all()

@router.post("/")
def crear_solicitud(
    solicitud: SolicitudCreate,
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    nueva = SolicitudCurso(
        nombre=solicitud.nombre,
        descripcion=solicitud.descripcion,
        duracion=solicitud.duracion,
        id_usuario=usuario.id
    )
    db.add(nueva)
    db.commit()
    db.refresh(nueva)
    return {"mensaje": "Solicitud enviada correctamente"}