from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from typing import Optional
from jose import jwt

from app.database import SessionLocal, get_db
from app.models import Curso, Inscripcion, Usuario, SolicitudCurso
from app.dependencies import get_current_user, verificar_rol_admin
from app.schemas import CursoCreate, CursoOut, CursoUpdate
from app.dependencies import SECRET_KEY, ALGORITHM  # asegúrate de tener esto en tu config
from app.database import get_db
from sqlalchemy.orm import joinedload




# Crea un router para los cursos
router = APIRouter(
    prefix="/cursos",
    tags=["cursos"]
)

# Función auxiliar para permitir acceder a cursos sin login
def get_current_user_optional(
    request: Request,
    db: Session = Depends(get_db)
) -> Optional[Usuario]:
    auth = request.headers.get("Authorization")
    if not auth:
        return None
    try:
        token = auth.split(" ")[1]
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return db.query(Usuario).filter(Usuario.id == payload["sub"]).first()
    except:
        return None

# Función para obtener la sesión de base de datos en cada petición
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Ruta para obtener todos los cursos
@router.get("/")
def obtener_cursos(
    db: Session = Depends(get_db),
    usuario: Optional[Usuario] = Depends(get_current_user_optional)
):
    if usuario and usuario.id_rol in [1, 2]:  # super o admin
        return db.query(Curso).all()
    else:  # usuario normal o no logado
        return db.query(Curso).filter(Curso.disponible == True).all()



from sqlalchemy.orm import joinedload
@router.get("/")
def obtener_cursos(
    db: Session = Depends(get_db),
    usuario: Optional[Usuario] = Depends(get_current_user_optional)
):
    query = db.query(Curso).options(joinedload(Curso.profesor))

    if not usuario or usuario.id_rol not in [1, 2]:
        query = query.filter(Curso.disponible == True)

    cursos = query.all()

    resultado = []
    for curso in cursos:
        inscritos = db.query(Inscripcion).filter(Inscripcion.id_curso == curso.id).count()
        plazas_restantes = curso.plazas_disponibles - inscritos

        profesor_data = None
        if curso.profesor:
            profesor_data = {
                "id": curso.profesor.id,
                "nombre": curso.profesor.nombre,
                "apellidos": curso.profesor.apellidos
            }

        resultado.append({
            "id": curso.id,
            "nombre": curso.nombre,
            "descripcion": curso.descripcion,
            "duracion": curso.duracion,
            "plazas_disponibles": max(plazas_restantes, 0),
            "profesor": profesor_data
        })

    return resultado





@router.get("/cursos/{curso_id}")
def obtener_curso_por_id(curso_id: int, db: Session = Depends(get_db)):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")
    return curso


@router.put("/cursos/{curso_id}")
def actualizar_curso(curso_id: int, datos_actualizados: CursoUpdate, db: Session = Depends(get_db)):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")

    curso.nombre = datos_actualizados.nombre
    curso.descripcion = datos_actualizados.descripcion
    curso.duracion = datos_actualizados.duracion
    curso.disponible = datos_actualizados.disponible

    db.commit()
    db.refresh(curso)
    return curso

@router.delete("/cursos/{curso_id}")
def eliminar_curso(curso_id: int, db: Session = Depends(get_db)):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")

    db.delete(curso)
    db.commit()
    return {"mensaje": f"Curso con ID {curso_id} eliminado correctamente"}



@router.post("/{curso_id}/inscribirse")
def inscribirse(
    curso_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso or not curso.disponible:
        raise HTTPException(status_code=404, detail="Curso no disponible")

    # Evitar inscripción duplicada ANTES de restar plazas
    ya_inscrito = db.query(Inscripcion).filter_by(
        id_usuario=current_user.id, id_curso=curso_id).first()
    if ya_inscrito:
        raise HTTPException(status_code=400, detail="Ya estás inscrito")

    # Solo si es estudiante (tipo 'user') se descuenta plaza
    if current_user.tipo == "estudiante":
        if curso.plazas_disponibles <= 0:
            raise HTTPException(...)
        curso.plazas_disponibles -= 1
    if current_user.tipo != "estudiante":
        raise HTTPException(status_code=403, detail="Solo los estudiantes pueden inscribirse")



    nueva = Inscripcion(id_usuario=current_user.id, id_curso=curso_id)
    db.add(nueva)
    db.commit()
    return {"mensaje": "Inscripción exitosa"}



@router.get("/mis-cursos")
def obtener_mis_cursos(
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    inscripciones = db.query(Inscripcion).filter(Inscripcion.id_usuario == usuario.id).all()
    
    cursos = []
    for inscripcion in inscripciones:
        curso = db.query(Curso).filter(Curso.id == inscripcion.id_curso).first()
        if curso:
            cursos.append(curso)

    return cursos

@router.get("/mis-cursos", tags=["cursos"])
def obtener_mis_cursos(
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    inscripciones = db.query(Inscripcion).filter(Inscripcion.id_usuario == usuario.id).all()
    cursos = [db.query(Curso).filter(Curso.id == insc.id_curso).first() for insc in inscripciones]
    return cursos

@router.get("/{curso_id}/inscritos", tags=["cursos"])
def ver_usuarios_inscritos(
    curso_id: int,
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(verificar_rol_admin)
):
    inscripciones = db.query(Inscripcion).filter(Inscripcion.id_curso == curso_id).all()
    usuarios = [db.query(Usuario).filter(Usuario.id == insc.id_usuario).first() for insc in inscripciones]
    return usuarios

@router.put("/{curso_id}/deshabilitar")
def deshabilitar_curso(
    curso_id: int,
    db: Session = Depends(get_db),
    admin: Usuario = Depends(verificar_rol_admin)
):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")
    curso.disponible = False
    db.commit()
    return {"mensaje": f"Curso con ID {curso_id} deshabilitado"}

@router.put("/{curso_id}/habilitar")
def habilitar_curso(
    curso_id: int,
    db: Session = Depends(get_db),
    admin: Usuario = Depends(verificar_rol_admin)
):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")
    curso.disponible = True
    db.commit()
    return {"mensaje": f"Curso con ID {curso_id} habilitado"}

@router.get("/disponibles")
def cursos_disponibles(db: Session = Depends(get_db)):
    cursos = db.query(Curso).filter(Curso.disponible == True).all()
    return cursos

@router.get("/{curso_id}/inscritos")
def ver_usuarios_inscritos(
    curso_id: int,
    db: Session = Depends(get_db),
    admin: Usuario = Depends(verificar_rol_admin)
):
    inscripciones = db.query(Inscripcion).filter(Inscripcion.id_curso == curso_id).all()
    usuarios = [db.query(Usuario).filter(Usuario.id == insc.id_usuario).first() for insc in inscripciones]
    return usuarios

@router.delete("/{curso_id}/inscribir/{usuario_id}")
def eliminar_inscripcion(
    curso_id: int,
    usuario_id: int,
    db: Session = Depends(get_db),
    usuario_actual: Usuario = Depends(get_current_user)
):
    # Solo admin o super pueden eliminar
    if usuario_actual.id_rol not in [1, 2]:
        raise HTTPException(status_code=403, detail="No autorizado")

    inscripcion = db.query(Inscripcion).filter_by(id_usuario=usuario_id, id_curso=curso_id).first()

    if not inscripcion:
        raise HTTPException(status_code=404, detail="Inscripción no encontrada")

    db.delete(inscripcion)
    # Recuperar el curso y aumentar plazas
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if curso and curso.plazas_disponibles is not None:
        curso.plazas_disponibles += 1
    db.commit()
    return {"mensaje": "Inscripción eliminada correctamente"}



# routers/courses.py (o uno nuevo: solicitudes.py)
@router.post("/solicitar-curso")
def solicitar_curso(
    curso: CursoCreate,
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    solicitud = SolicitudCurso(
        nombre=curso.nombre,
        descripcion=curso.descripcion,
        duracion=curso.duracion,
        id_usuario=usuario.id
    )
    db.add(solicitud)
    db.commit()
    return {"mensaje": "Solicitud enviada correctamente"}

@router.post("/cursos/{curso_id}/inscribir/{usuario_id}")
def inscribirse(
    curso_id: int,
    usuario_id: int,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso or not curso.disponible:
        raise HTTPException(status_code=404, detail="Curso no disponible")

    # Obtener el usuario al que se va a inscribir
    usuario = db.query(Usuario).filter(Usuario.id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    # Solo para alumnos (tipo "user"), verificar plazas
    if usuario.tipo == "user":
        if curso.plazas_disponibles <= 0:
            raise HTTPException(status_code=400, detail="No hay plazas disponibles")
        curso.plazas_disponibles -= 1  # ← restar solo si es alumno

    # Verificar si ya está inscrito
    inscripcion_existente = db.query(Inscripcion).filter_by(id_usuario=usuario_id, id_curso=curso_id).first()
    if inscripcion_existente:
        raise HTTPException(status_code=400, detail="Ya está inscrito")

    nueva = Inscripcion(id_usuario=usuario_id, id_curso=curso_id)
    db.add(nueva)
    db.commit()

    return {"mensaje": "Inscripción exitosa"}

@router.post("/{curso_id}/asignar-profesor")
def asignar_profesor(
    curso_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    curso = db.query(Curso).filter(Curso.id == curso_id).first()
    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")

    if current_user.tipo != "profesor":
        raise HTTPException(status_code=403, detail="Solo los profesores pueden asignarse")

    if curso.id_profesor:
        raise HTTPException(status_code=400, detail="Ya hay un profesor asignado")

    curso.id_profesor = current_user.id
    db.commit()
    return {"mensaje": "Profesor asignado correctamente"}


@router.post("/cursos/{curso_id}/asignar-profesor")
def asignar_profesor_a_curso(
    curso_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    if current_user.tipo != "profesor":
        raise HTTPException(status_code=403, detail="Solo profesores pueden asignarse a cursos")

    curso = db.query(Curso).filter(Curso.id == curso_id).first()

    if not curso:
        raise HTTPException(status_code=404, detail="Curso no encontrado")

    if curso.id_profesor:
        raise HTTPException(status_code=400, detail="Este curso ya tiene un profesor asignado")

    curso.id_profesor = current_user.id
    db.commit()

    return {"mensaje": "Profesor asignado correctamente"}

from fastapi import status

@router.post("/", status_code=status.HTTP_201_CREATED)
def crear_curso(
    curso: CursoCreate,
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(verificar_rol_admin)
):
    nuevo_curso = Curso(
        nombre=curso.nombre,
        descripcion=curso.descripcion,
        duracion=curso.duracion,
        disponible=curso.disponible,
        plazas_disponibles=curso.plazas_disponibles,
        id_profesor=curso.id_profesor if curso.id_profesor else None
    )
    db.add(nuevo_curso)
    db.commit()
    db.refresh(nuevo_curso)
    return nuevo_curso
