from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Usuario, Rol
from app.schemas import LoginRequest, TokenResponse
from jose import jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta


router = APIRouter(
    prefix="/auth",
    tags=["auth"]
)

SECRET_KEY = "claveultrasecreta"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)  


def get_password_hash(password: str):
    return pwd_context.hash(password)

@router.post("/login", response_model=TokenResponse)  # ✅ IMPORTANTE
def login(request: LoginRequest, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.email == request.email).first()

    if not usuario:
        raise HTTPException(status_code=401, detail="Email no registrado")
    if not usuario.habilitado:
        raise HTTPException(status_code=403, detail="Usuario no habilitado")
    if not verify_password(request.contrasena, usuario.password):
        raise HTTPException(status_code=401, detail="Contraseña incorrecta")

    rol_obj = db.query(Rol).filter(Rol.id == usuario.id_rol).first()
    if not rol_obj:
        raise HTTPException(status_code=500, detail="Rol no válido")

    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(usuario.id),
        "rol": rol_obj.nombre,
        "exp": expire
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

    return {
        "access_token": token,
        "token_type": "bearer",
        "rol": rol_obj.nombre  # ✅ Este campo ya será validado por el schema
    }
