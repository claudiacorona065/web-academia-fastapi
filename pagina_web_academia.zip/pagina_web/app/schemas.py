from pydantic import BaseModel, EmailStr
from typing import Optional
from enum import Enum
from typing import Literal
from pydantic import BaseModel
from typing import List
# ---------------------- ENUMS ----------------------
class TipoUsuario(str, Enum):
    user = 'user'
    admin = 'admin'

class RolEnum(int, Enum):
    user = 3
    admin = 2
    super = 1

# ---------------------- USUARIO ----------------------
class UsuarioCreate(BaseModel):
    nombre: str
    apellidos: str
    email: str
    contrasena: str
    tipo: Literal['estudiante', 'profesor', 'otro'] = 'user'
    id_rol: int = 3

class UsuarioOut(BaseModel):
    id: int
    nombre: str
    apellidos: str
    email: EmailStr
    tipo: str

    class Config:
        from_attributes = True  # Usado en vez de orm_mode en Pydantic v2

# ---------------------- AUTH ----------------------
class LoginRequest(BaseModel):
    email: str
    contrasena: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    sub: str
    rol: int

# ✅ NUEVO schema para incluir el rol explícitamente
class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    rol: str

# ---------------------- CURSOS ----------------------
class CursoCreate(BaseModel):
    nombre: str
    descripcion: str
    duracion: int
    disponible: bool = True
    plazas_disponibles: int
    id_profesor: Optional[int] = None


class CursoUpdate(BaseModel):
    nombre: str
    descripcion: str
    duracion: int
    disponible: bool
    plazas_disponibles: int

class CursoOut(BaseModel):
    id: int
    nombre: str
    descripcion: str
    duracion: int
    disponible: bool
    plazas_disponibles: int
    profesor_nombre: Optional[str] = None

    class Config:
        from_attributes = True
#----------------------- SOLICITUDES ----------------------
class UsuarioUpdate(BaseModel):
    nombre: str
    apellidos: str
    email: str

class ProfesorOut(BaseModel):
    id: int
    nombre: str
    apellidos: str

    model_config = {
        "from_attributes": True
    }

class UsuarioTipoUpdate(BaseModel):
    tipo: Literal["estudiante", "profesor", "otro"]
