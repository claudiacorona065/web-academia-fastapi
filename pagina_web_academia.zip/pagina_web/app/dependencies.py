from fastapi import Depends, HTTPException, status, APIRouter
from sqlalchemy.orm import Session
from app.models import Usuario
from app.database import get_db
from jose import jwt, JWTError
from fastapi.security import HTTPBearer
from fastapi.security import OAuth2PasswordBearer


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

SECRET_KEY = "claveultrasecreta"
ALGORITHM = "HS256"
security = OAuth2PasswordBearer(tokenUrl="token")

# Nuevo esquema: HTTP Bearer (pides token manualmente)
bearer_scheme = HTTPBearer()

# Obtener usuario actual a partir del token
from fastapi import Depends, HTTPException, status, Header
from jose import JWTError, jwt

def get_current_user(authorization: str = Header(...), db: Session = Depends(get_db)):
    token = authorization.split(" ")[1]  # Obtener el token del encabezado Authorization
    try:
        # Decodificamos el token para verificarlo
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise JWTError("Token inválido")
        user = db.query(Usuario).filter(Usuario.id == user_id).first()
        if user is None:
            raise JWTError("Usuario no encontrado")
        return user
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido o expirado",
            headers={"WWW-Authenticate": "Bearer"},
        )


# Ruta protegida que requiere autenticación
router = APIRouter()

@router.get("/profile")
def get_profile(user_id: str = Depends(get_current_user)):
    # Aquí puedes devolver los datos del usuario
    return {"user_id": user_id, "profile_info": "Datos del perfil del usuario"}

def verificar_rol_super(usuario: Usuario = Depends(get_current_user)):
    if usuario.id_rol != 1:
        raise HTTPException(
            status_code=403,
            detail="Acceso denegado: se requiere rol SUPER"
        )
    return usuario

def verificar_rol_admin(usuario: Usuario = Depends(get_current_user)):
    if usuario.id_rol not in [1, 2]:
        raise HTTPException(
            status_code=403,
            detail="Acceso denegado: se requiere rol ADMIN o SUPER"
        )
    return usuario

def credentials_exception():
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="No se pudo validar el token",
        headers={"WWW-Authenticate": "Bearer"},
    )

