from fastapi import FastAPI, Depends
from fastapi.security import HTTPBearer
from app.database import engine, SessionLocal
from app import models
from app.routers import courses, usuarios, auth
from app.dependencies import get_current_user
from app.schemas import UsuarioOut
from sqlalchemy.orm import Session
from app.models import Rol
from fastapi.middleware.cors import CORSMiddleware
from app.routers import usuarios  # ✅ Importación
from app.routers import solicitudes
from app.routers import courses


app = FastAPI()

origins = [
    "http://localhost:5000",  # Flask
    "http://127.0.0.1:5000",
    "http://localhost:3000",  # React si lo usas
    "http://127.0.0.1:3000"
]




# Agregar middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Crear roles por defecto si no existen
def crear_roles_base():
    db: Session = SessionLocal()
    roles = {1: "super", 2: "admin", 3: "user"}
    for id_, nombre in roles.items():
        if not db.query(Rol).filter(Rol.id == id_).first():
            nuevo_rol = Rol(id=id_, nombre=nombre)
            db.add(nuevo_rol)
    db.commit()
    db.close()

models.Base.metadata.create_all(bind=engine)
crear_roles_base()

# Routers
app.include_router(auth.router)
app.include_router(usuarios.router)
app.include_router(courses.router)
from app.routers import solicitudes


# Ruta raíz
@app.get("/")
def read_root():
    return {"mensaje": "¡API de la academia funcionando correctamente!"}

# Ruta protegida
@app.get("/usuarios/me", response_model=UsuarioOut)
def leer_usuario_actual(usuario: UsuarioOut = Depends(get_current_user)):
    return usuario


import logging
logging.basicConfig(level=logging.DEBUG)

app.include_router(solicitudes.router)
app.include_router(courses.router, prefix="/cursos", tags=["Cursos"])
app.include_router(courses.router, prefix="/cursos")