from flask import Flask, render_template
from flask import Flask, send_from_directory

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/mis-cursos")
def mis_cursos():
    return render_template("mis-cursos.html")

@app.route("/panel-admin")
def panel_admin():
    return render_template("panel-admin.html")

@app.route("/crear-curso")
def crear_curso():
    return render_template("crear-curso.html")

@app.route("/editar-curso")
def editar_curso():
    return render_template("editar-curso.html")

@app.route("/perfil")
def perfil():
    return send_from_directory("templates", "perfil.html")

@app.route("/solicitar-curso")
def solicitar_curso():
    return render_template("solicitar-curso.html")

@app.route("/bandeja-solicitudes")
def bandeja_solicitudes():
    return render_template("bandeja-solicitudes.html")

@app.route("/panel-solicitudes")
def panel_solicitudes():
    return render_template("panel-solicitudes.html")

@app.route("/editar-perfil.html")
def editar_perfil():
    return render_template("editar-perfil.html")

if __name__ == "__main__":
    app.run(debug=True, port=5000)