function construirNavbar(rol) {
  const nav = document.createElement("nav");
  nav.classList.add("navbar");

  nav.innerHTML = `
    <div class="nav-logo">
      <a href="/">
        <img src="/static/img/UAX.jpeg" alt="Academia UAX" style="height: 40px; border-radius: 6px; vertical-align: middle;">
      </a>
    </div>
    <div class="nav-links" id="nav-links"></div>
    <div class="nav-logout" id="logout-btn" style="display:none;">
      <button class="session-btn" id="btn-cerrar-sesion">Cerrar Sesión</button>
    </div>
  `;
  document.body.prepend(nav);



  const links = nav.querySelector("#nav-links");
  const logout = nav.querySelector("#logout-btn");

  let html = "";

  if (rol) {
    html += `
      <a href="/">Inicio</a>
      <a href="/mis-cursos">Mis Cursos</a>
      <a href="/perfil">Mi Perfil</a>
    `;

    if (rol !== "admin" && rol !== "super") {
      html += `<a href="/solicitar-curso">Solicitar Curso</a>`;
    }
    

    if (rol === "admin" || rol === "super") {
      html += `<a href="/crear-curso">Crear Curso</a>`;
      html += `<a href="/bandeja-solicitudes">Solicitudes</a>`;
    }

    if (rol === "super") {
      html += `<a href="/panel-admin">Panel Admin</a>`;
    }

    logout.style.display = "block";
  } else {
    html += `
      <a href="/">Inicio</a>
      <a href="/login">Iniciar sesión</a>
      <a href="/register">Registrarse</a>
    `;
    logout.style.display = "none";
  }

  links.innerHTML = html;

  const btnCerrar = document.getElementById("btn-cerrar-sesion");
  if (btnCerrar) {
    btnCerrar.addEventListener("click", cerrarSesion);
  }
}

function cerrarSesion() {
  localStorage.removeItem("token");
  location.href = "/";
}

async function cargarNavbar() {
  const token = localStorage.getItem("token");
  if (!token) {
    construirNavbar(null);
    return;
  }

  try {
    const res = await fetch("http://localhost:8000/usuarios/me", {
      headers: { "Authorization": `Bearer ${token}` }
    });

    if (res.ok) {
      const data = await res.json();
      construirNavbar(data.tipo);
    } else {
      construirNavbar(null);
    }
  } catch {
    construirNavbar(null);
  }
}
function renderCursoAdmin(curso, contenedor) {
  const div = document.createElement("div");
  div.className = "curso";

  div.innerHTML = `
    <div class="curso-info">
      <h3>${curso.nombre}</h3>
      <p>${curso.descripcion}</p>
    </div>
    <div class="curso-meta">
      <p><strong>Duración:</strong> ${curso.duracion} horas</p>
      <p><strong>Plazas disponibles:</strong> ${curso.plazas_disponibles}</p>
      <button class="btn-amarillo">Editar</button>
      <button class="btn-amarillo">Ver inscritos</button>
    </div>
  `;

  contenedor.appendChild(div);

  
}